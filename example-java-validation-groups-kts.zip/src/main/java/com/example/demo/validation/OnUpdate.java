
package com.example.demo.validation;

public interface OnUpdate {}

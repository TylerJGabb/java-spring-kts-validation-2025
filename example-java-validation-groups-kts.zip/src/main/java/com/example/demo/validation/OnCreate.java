
package com.example.demo.validation;

public interface OnCreate {}
